(function(){window.location="/options/options.html"})();
